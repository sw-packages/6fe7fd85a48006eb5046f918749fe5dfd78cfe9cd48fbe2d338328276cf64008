
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl45/types.h>
#include <glbinding/gl45/boolean.h>
#include <glbinding/gl45/values.h>
#include <glbinding/gl45/bitfield.h>
#include <glbinding/gl45/enum.h>
#include <glbinding/gl45/functions.h>
